# Scientific publication assets v2

This package adds the assets missing from the first audit-oriented release.
It follows the agreed list:

- final chart assignment;
- operational pipeline map;
- sparse spectral supervision;
- direct PINN versus reference growth-rate validation;
- PINN-seeded GEP versus reference validation;
- GEP improvement factor;
- random/off-grid validation distributions and parity plots;
- four separate final modal-error maps;
- pressure-mode overlap-defect map;
- stratified selection of 20 modal points;
- optional Blumen overlay;
- optional long-wave and N-convergence audits;
- optional two 20-point modal PDFs.

## Installation in the repository

From the repository root on Jean Zay:

```bash
mkdir -p scripts/assets_v2 slurm/offgrid_validation slurm/log
cp fullrect_missing_assets_v2/scripts/*.py scripts/assets_v2/
cp fullrect_missing_assets_v2/slurm/*.slurm slurm/offgrid_validation/
cp -r fullrect_missing_assets_v2/contracts scripts/assets_v2/

module purge
module load pytorch-gpu/py3/2.1.1
python -m py_compile scripts/assets_v2/*.py
bash -n slurm/offgrid_validation/build_scientific_assets_v2.slurm
bash -n slurm/offgrid_validation/build_mode_pdfs_v2.slurm
```

## Stage 1 — assets generated from the validated 384-point release

```bash
asset_v2_job=$(sbatch --parsable slurm/offgrid_validation/build_scientific_assets_v2.slurm)
echo "$asset_v2_job"
squeue -j "$asset_v2_job"
```

Expected output directory:

```text
assets/pinn_subsonic/local_atlas_v1/publication_assets_scientific_v2
```

Core outputs:

```text
figures/Fig02_atlas_architecture_and_coverage.{pdf,png}
figures/Fig02a_atlas_status_footprints.{pdf,png}
figures/Fig02b_coverage_multiplicity.{pdf,png}
figures/SuppFig03_final_chart_assignment.{pdf,png}
figures/Fig02c_operational_pipeline_map.{pdf,png}
figures/Fig03_sparse_spectral_supervision.{pdf,png}
figures/Fig04_ci_direct_and_errors.{pdf,png}
figures/Fig05_ci_gep_parity_and_gain.{pdf,png}
figures/SuppFig_random_offgrid_validation.{pdf,png}
figures/Fig07_final_modal_error_heatmaps.{pdf,png}
figures/SuppFig_modal_overlap_defect.{pdf,png}
data/validation_mode_points_20.csv
```

## Blumen versus PINN/GEP

The script auto-discovers a file named one of:

```text
blumen_ci_datasets.csv
blumen_ci_reference.csv
ci_reference.csv
```

A Blumen CSV must contain:

```text
Mach or M
alpha or eta
ci or c_i or ci_reference or value
```

Optional curve identifier:

```text
curve_id / isoline / level / dataset / branch
```

Explicit command:

```bash
module purge
module load pytorch-gpu/py3/2.1.1
export PYTHONPATH="$PWD/scripts/assets_v2:$PWD:${PYTHONPATH:-}"

python scripts/assets_v2/build_ci_and_atlas_assets.py \
  --blumen-csv /absolute/path/to/blumen_ci_datasets.csv \
  --output-dir assets/pinn_subsonic/local_atlas_v1/publication_assets_scientific_v2
```

Output:

```text
figures/Fig04a_Blumen_PINN_GEP_overlay.{pdf,png}
figures/Fig04b_Blumen_error_maps.{pdf,png}          # when interpolation support is sufficient
figures/Fig04c_Blumen_Mach_cuts.{pdf,png}           # when interpolation support is sufficient
```

## Stage 2 — two 20-point mode PDFs

The selector creates:

```text
data/validation_mode_points_20.csv
```

The PDF generator requires one profile file per point for each pipeline:

```text
mode_profiles/direct/<point_id>.npz
mode_profiles/gep/<point_id>.npz
```

See:

```text
contracts/mode_profile_schema.md
```

If equivalent files already exist in the workspace, canonicalize them:

```bash
OUT="assets/pinn_subsonic/local_atlas_v1/publication_assets_scientific_v2"

python scripts/assets_v2/canonicalize_mode_profiles.py \
  --points-csv "$OUT/data/validation_mode_points_20.csv" \
  --pipeline direct \
  --search-root assets/pinn_subsonic \
  --search-root results \
  --output-dir "$OUT/mode_profiles"

python scripts/assets_v2/canonicalize_mode_profiles.py \
  --points-csv "$OUT/data/validation_mode_points_20.csv" \
  --pipeline gep \
  --search-root assets/pinn_subsonic \
  --search-root results \
  --output-dir "$OUT/mode_profiles"
```

Then:

```bash
mode_pdf_job=$(sbatch --parsable slurm/offgrid_validation/build_mode_pdfs_v2.slurm)
echo "$mode_pdf_job"
```

Outputs:

```text
supplement/supp_modes_direct_PINN_vs_classic_20_points.pdf
supplement/supp_modes_PINN_GEP_vs_classic_GEP_20_points.pdf
figures/Fig06_representative_modes.{pdf,png}
```

If the canonicalization report says `missing`, the mode arrays were not persisted by the previous validation jobs. A small extraction campaign is then required; the required output schema is fully specified in `contracts/mode_profile_schema.md`. Do not rerun the 384-point spectral validation merely to make plots: extract only the selected 20 points.

## Long-wave and convergence audits

The audit script recursively discovers CSVs containing mapping sweeps or N-convergence results:

```bash
python scripts/assets_v2/make_numerical_audits.py \
  --output-dir assets/pinn_subsonic/local_atlas_v1/publication_assets_scientific_v2
```

Possible outputs:

```text
figures/SuppFig08_longwave_mapping_audit.{pdf,png}
figures/SuppFig07_GEP_N_convergence.{pdf,png}
figures/SuppFig09_near_neutral_continuation_audit.{pdf,png}
figures/SuppFig10_bidirectional_continuation_overlap.{pdf,png}
```

The script does not invent missing numerical sweeps. It records unavailable inputs in:

```text
numerical_audit_report.json
```

## Input inventory

```bash
python scripts/assets_v2/inventory_missing_inputs.py
```

This lists Blumen files, mode profiles, mapping sweeps, convergence CSVs, and continuation paths, including CSV column names.

## Validation

```bash
python scripts/assets_v2/check_assets_v2.py \
  --asset-dir assets/pinn_subsonic/local_atlas_v1/publication_assets_scientific_v2
```

The checker distinguishes:

- assets that must be generated immediately from the current validated release;
- assets requiring Blumen source data, mode-profile extraction, or numerical sweep CSVs.
