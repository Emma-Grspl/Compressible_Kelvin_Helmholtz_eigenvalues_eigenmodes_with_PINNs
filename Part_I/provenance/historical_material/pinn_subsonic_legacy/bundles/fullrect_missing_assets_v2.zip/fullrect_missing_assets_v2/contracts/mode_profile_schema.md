# Canonical mode-profile schema

One file per validation point and per comparison pipeline:

```text
mode_profiles/direct/<point_id>.npz
mode_profiles/gep/<point_id>.npz
```

Required arrays:

```text
y
p_ref,   p_pred
rho_ref, rho_pred
u_ref,   u_pred
v_ref,   v_pred
```

The profile arrays may be stored directly as complex NumPy arrays. A CSV is also accepted with columns:

```text
y
p_ref_real,p_ref_imag,p_pred_real,p_pred_imag
rho_ref_real,rho_ref_imag,rho_pred_real,rho_pred_imag
u_ref_real,u_ref_imag,u_pred_real,u_pred_imag
v_ref_real,v_ref_imag,v_pred_real,v_pred_imag
```

Optional scalar metadata in NPZ:

```text
Mach, eta, alpha, ci_ref, ci_pred, chart_id
```

The PDF generator phase-aligns each predicted field against its reference before plotting.
