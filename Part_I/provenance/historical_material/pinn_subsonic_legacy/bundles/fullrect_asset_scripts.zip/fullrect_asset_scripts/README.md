# Fullrect publication assets

This package builds the final publication assets for the validated subsonic KH local PINN atlas.

## Consolidated asset list

### Canonical data assets

- `data/atlas_catalog.csv`
- `data/atlas_manifest_final.csv`
- `data/gep_regime_policy.csv`
- `data/gep_regime_policy_grid.csv`
- `data/coverage_grid.csv`
- `data/validation_pointwise.csv`
- `data/release_checks.csv`
- `data/release_summary.json`
- `data/atlas_fullrect_gep_final_all_points.csv`
- `data/atlas_fullrect_gep_final_metrics_by_chart.csv`
- `data/offgrid_continuation_N401_summary_55.csv`
- `data/offgrid_reference_branch_corrections.csv`
- `data/offgrid_0246_branch_resolution.csv`

### Publication figures

1. `fig01_atlas_chart_footprints`: local-chart footprint map.
2. `fig02_coverage_multiplicity`: coverage multiplicity over `(M, eta)`.
3. `fig03_gep_regime_policy`: standard, long-wave, extreme-long-wave and near-neutral policies.
4. `fig04_offgrid_ci_abs_discrepancy`: final `ci` versus the raw classical reference; corrected references are circled.
5. `fig05_offgrid_modal_error_max`: maximum relative error over `p, rho, u, v`.
6. `fig06_offgrid_pressure_overlap`: pressure-mode overlap.
7. `fig07_near_neutral_ci_zoom`: raw classical, independent GEP and final branch-selected `ci` near neutrality.
8. `fig08_reference_corrections`: the 21 continuation-corrected reference points.
9. `fig09_OFFGRID_0246_branch_ci`: primary and secondary branches for the exceptional point.
10. `fig10_OFFGRID_0246_branch_overlap`: overlap audit for the exceptional point.

Every figure is written as both PDF and PNG.

### Publication tables

- `tables/table01_metrics_by_gep_regime.csv`
- `tables/table02_metrics_by_chart.csv`
- `tables/table03_worst_offgrid_points.csv`
- `tables/table04_reference_corrections.csv`

### Integrity

- `asset_manifest.csv`: path, byte size and SHA-256 checksum of every generated asset.

## Installation in the repository

Copy:

```bash
cp scripts/build_fullrect_publication_assets.py \
  "$WORK/These_PINN_KH_RT/scripts/dev/"

cp scripts/check_fullrect_publication_assets.py \
  "$WORK/These_PINN_KH_RT/scripts/dev/"

cp slurm/build_fullrect_publication_assets.slurm \
  "$WORK/These_PINN_KH_RT/slurm/offgrid_validation/"
```

## Direct execution

```bash
cd "$WORK/These_PINN_KH_RT"
module purge
module load pytorch-gpu/py3/2.1.1
export PYTHONPATH="$PWD:${PYTHONPATH:-}"

python scripts/dev/build_fullrect_publication_assets.py
python scripts/dev/check_fullrect_publication_assets.py
```

## Slurm execution

```bash
cd "$WORK/These_PINN_KH_RT"
mkdir -p slurm/log slurm/offgrid_validation

asset_job=$(sbatch --parsable \
  slurm/offgrid_validation/build_fullrect_publication_assets.slurm)

echo "Asset job: $asset_job"
squeue -j "$asset_job"
```

## Output directory

```text
assets/pinn_subsonic/local_atlas_v1/publication_assets_fullrect_v1/
```
