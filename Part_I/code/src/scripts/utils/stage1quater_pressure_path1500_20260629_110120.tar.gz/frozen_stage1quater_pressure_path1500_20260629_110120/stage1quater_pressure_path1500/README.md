# Stage 1quater pressure-first diagnostics

- source checkpoint directory: `model_saved/kh_subsonic_2d_hybrid4ci_stage1quater_pressure`
- training uses only pressure physics: pressure ODE, Robin BC, and center gauge
- Stage 0 supplies the `c_i(alpha, M)` head and it is frozen by default
- the classical solver is used here only for post-processing diagnostics
- the classical solver is not used inside the training loss

## Diagnostic points
- M=0.50, alpha=0.30: ci_abs_err=1.173e-05, p_rel=9.022e-02, u_rel=1.633e-01, v_rel=1.385e-01
- M=0.50, alpha=0.50: ci_abs_err=9.005e-04, p_rel=9.722e-02, u_rel=5.461e-01, v_rel=1.736e-01
- M=0.50, alpha=0.70: ci_abs_err=7.619e-04, p_rel=1.217e-01, u_rel=1.189e+00, v_rel=2.100e-01
