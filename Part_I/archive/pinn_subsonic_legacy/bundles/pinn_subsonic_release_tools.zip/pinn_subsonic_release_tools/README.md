# Outils de vérification et d’organisation `pinn_subsonic`

## Installation dans le dépôt

Depuis la racine du dépôt local ou sur Jean Zay :

```bash
mkdir -p scripts/release
cp scripts/audit_requested_assets.py scripts/release/
cp scripts/build_pinn_subsonic_curated_tree.py scripts/release/
```

## Audit sur Jean Zay

```bash
module purge
module load pytorch-gpu/py3/2.1.1

python scripts/release/audit_requested_assets.py \
  --repo-root "$WORK/These_PINN_KH_RT" \
  --output-dir assets/pinn_subsonic/asset_audit
```

Le script écrit :

```text
assets/pinn_subsonic/asset_audit/requested_assets_audit.csv
assets/pinn_subsonic/asset_audit/requested_assets_audit.json
```

Le code retour `2` signifie qu’au moins un asset reste manquant ; les rapports sont quand même écrits.

## Construction de l’arborescence curatée

Cette opération ne déplace ni ne supprime les résultats de recherche sous
`assets/pinn_subsonic/local_atlas_v1`.

```bash
python scripts/release/build_pinn_subsonic_curated_tree.py \
  --repo-root "$WORK/These_PINN_KH_RT" \
  --code-dir pinn_subsonic \
  --asset-dir assets/pinn_subsonic/release_v1 \
  --model-mode hardlink
```

Sur Jean Zay, `hardlink` évite de dupliquer l’espace disque des checkpoints.
Lors du `rsync` vers le Mac, les fichiers sont transférés normalement.

## Synchronisation vers le Mac

Depuis la racine locale `These_PINN_KH_RT` :

```bash
rsync -avP \
  -e "ssh -J emma.grospellier@pascal1.cpht.polytechnique.fr" \
  usv13rn@jean-zay.idris.fr:/lustre/fswork/projects/rech/fdb/usv13rn/These_PINN_KH_RT/pinn_subsonic/ \
  pinn_subsonic/

rsync -avP \
  -e "ssh -J emma.grospellier@pascal1.cpht.polytechnique.fr" \
  usv13rn@jean-zay.idris.fr:/lustre/fswork/projects/rech/fdb/usv13rn/These_PINN_KH_RT/assets/pinn_subsonic/release_v1/ \
  assets/pinn_subsonic/release_v1/
```

## Vérification locale de l’intégrité

```bash
cd "$HOME/Thèse/These_PINN_KH_RT"
sha256sum -c assets/pinn_subsonic/release_v1/manifests/checksums.sha256
```

Sur macOS, si `sha256sum` n’est pas installé :

```bash
brew install coreutils

gsha256sum -c assets/pinn_subsonic/release_v1/manifests/checksums.sha256
```
